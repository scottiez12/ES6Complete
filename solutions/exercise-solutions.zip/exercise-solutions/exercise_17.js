const name = 'Name';
let age = 20;
const dateOfBirth = 'January 1 2016';
