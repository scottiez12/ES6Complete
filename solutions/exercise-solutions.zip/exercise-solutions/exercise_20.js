function fullName(firstName, lastName) {
  return `${firstName} ${lastName}`;
}
