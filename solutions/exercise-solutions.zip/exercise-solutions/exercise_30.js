function join(array1, array2) {
  return [...array1, ...array2];
}
