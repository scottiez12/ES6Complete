function addOffset(style = {}) {
  style.offset = '10px';
  return style;
}
